# Cutout: AI background removal SaaS (MERN)

Upload an image, get a transparent PNG. Users sign up, get free credits, process images,
compare before/after with a slider, swap in a solid background, download, and buy more credits.

**Stack:** MongoDB + Mongoose, Express, React (Vite), Node.js 18+.

## Features
- JWT auth (register, login, protected routes), bcrypt password hashing
- Credit system: each image costs 1 credit, taken atomically and refunded if processing fails
- AI provider layer: `removebg` (remove.bg API) or `mock` (free, returns the original so you can test the UI)
- Before/after compare slider, background color picker, PNG download
- Image history with delete
- Pricing page with demo checkout (add Stripe to go live)
- Helmet, CORS, rate-limited auth routes, upload type/size validation (JPG/PNG/WebP, 12 MB)

## Quick start
Requirements: Node 18+ and a running MongoDB (local or Atlas).

```bash
npm run install:all           # installs root, server and client deps
cp server/.env.example server/.env
# edit server/.env: set MONGO_URI and a long random JWT_SECRET
npm run dev
```
- Client: http://localhost:5173
- API:    http://localhost:5000

### Turn on real background removal
1. Get an API key at https://www.remove.bg/api
2. In `server/.env` set:
   ```
   BG_PROVIDER=removebg
   REMOVE_BG_API_KEY=your_key_here
   ```
3. Restart the server.

With `BG_PROVIDER=mock` the whole flow works, but the "cutout" is just the original image.

To use a different model (self-hosted `rembg`, Photoroom, Clipdrop), add a function to
`server/src/services/removeBg.js` and register it in `providers`.

## Production
```bash
npm run build        # builds client/dist
NODE_ENV=production npm start
```
The Express server serves `client/dist` and `/uploads`, so one process hosts everything.
Set `CLIENT_URL` to your real domain. Set `VITE_API_URL` only if the API lives on a different origin.

## Project layout
```
server/src
  index.js            app setup, static files, error handling
  config/db.js        MongoDB connection
  models/             User (credits, plan), Image
  middleware/         auth (JWT), error handler
  routes/             auth, images (upload + remove + history), billing
  services/removeBg.js  AI provider adapters
client/src
  pages/              Landing, Auth, Dashboard, History, Pricing
  components/         Navbar, CompareSlider, Protected
  context/AuthContext.jsx
```

## Before you launch (checklist)
- **Payments:** `POST /api/billing/purchase` is a demo that adds credits for free. Replace it with
  Stripe Checkout and add credits in a `checkout.session.completed` webhook.
- **Storage:** images are saved to `server/uploads`. Move to S3/Cloudinary for multiple servers or ephemeral hosts.
- **Secrets:** use a strong `JWT_SECRET`; never commit `.env`.
- **Email verification / password reset / admin panel** are not included.
