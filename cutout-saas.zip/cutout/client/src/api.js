import axios from 'axios';

const BASE = import.meta.env.VITE_API_URL || '';

const api = axios.create({ baseURL: BASE });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export const fileUrl = (path) => `${BASE}${path}`;
export const errorMessage = (err) =>
  err?.response?.data?.message || err?.message || 'Something went wrong. Try again.';

export default api;
