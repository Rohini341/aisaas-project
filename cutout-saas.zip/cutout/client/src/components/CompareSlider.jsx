import { useState } from 'react';

/**
 * Before/after slider. `after` sits on a transparency checkerboard (or a solid color),
 * `before` is revealed on the left of the handle.
 */
export default function CompareSlider({ before, after, bg }) {
  const [pos, setPos] = useState(50);

  return (
    <div className="compare" style={bg ? { background: bg } : undefined} data-checker={!bg}>
      <img className="compare-img" src={after} alt="Image with background removed" draggable="false" />
      <img
        className="compare-img compare-before"
        src={before}
        alt="Original image"
        draggable="false"
        style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
      />
      <div className="compare-line" style={{ left: `${pos}%` }} aria-hidden="true"><span /></div>
      <input
        type="range" min="0" max="100" value={pos}
        onChange={(e) => setPos(Number(e.target.value))}
        aria-label="Drag to compare original and result"
        className="compare-range"
      />
    </div>
  );
}
