import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="nav">
      <Link to="/" className="logo" aria-label="Cutout home">
        <span className="logo-mark" aria-hidden="true" />
        Cutout
      </Link>
      <nav>
        <NavLink to="/pricing">Pricing</NavLink>
        {user ? (
          <>
            <NavLink to="/app">Remove background</NavLink>
            <NavLink to="/history">My images</NavLink>
            <Link to="/pricing" className="credit-pill" title="Credits left">
              {user.credits} {user.credits === 1 ? 'credit' : 'credits'}
            </Link>
            <button className="link-btn" onClick={() => { logout(); navigate('/'); }}>Log out</button>
          </>
        ) : (
          <>
            <NavLink to="/login">Log in</NavLink>
            <Link to="/register" className="btn btn-sm">Start free</Link>
          </>
        )}
      </nav>
    </header>
  );
}
