import { useRef, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api, { errorMessage, fileUrl } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import CompareSlider from '../components/CompareSlider.jsx';

const SWATCHES = [
  { label: 'Transparent', value: null },
  { label: 'White', value: '#ffffff' },
  { label: 'Black', value: '#000000' },
  { label: 'Pink', value: '#ff2e7e' },
  { label: 'Blue', value: '#2563eb' },
];

export default function Dashboard() {
  const { user, patchUser } = useAuth();
  const inputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [result, setResult] = useState(null);
  const [bg, setBg] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [drag, setDrag] = useState(false);

  useEffect(() => () => preview && URL.revokeObjectURL(preview), [preview]);

  function pick(f) {
    if (!f) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) {
      setError('Use a JPG, PNG or WebP image.');
      return;
    }
    if (f.size > 12 * 1024 * 1024) {
      setError('Image is too large. Max size is 12 MB.');
      return;
    }
    setError('');
    setResult(null);
    setBg(null);
    setFile(f);
    setPreview(URL.createObjectURL(f));
  }

  async function process() {
    setBusy(true);
    setError('');
    try {
      const body = new FormData();
      body.append('image', file);
      const { data } = await api.post('/api/images/remove', body);
      setResult(data.image);
      patchUser({ credits: data.credits });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  // Download as PNG; if a background color is chosen, composite it on a canvas first
  async function download() {
    const name = (result.originalName || 'image').replace(/\.[^.]+$/, '') + '-cutout.png';
    let href = fileUrl(result.resultUrl);
    if (bg) {
      const img = new Image();
      img.src = href;
      await img.decode();
      const c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      const ctx = c.getContext('2d');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0);
      href = c.toDataURL('image/png');
    }
    const a = document.createElement('a');
    a.href = href;
    a.download = name;
    a.click();
  }

  function reset() {
    setFile(null); setPreview(''); setResult(null); setBg(null); setError('');
  }

  const outOfCredits = user.credits < 1;

  return (
    <section className="editor">
      <div className="editor-head">
        <h1>Remove background</h1>
        <p className="fine">{user.credits} {user.credits === 1 ? 'credit' : 'credits'} left. Each image uses one.</p>
      </div>

      {!file && (
        <div
          className={`drop ${drag ? 'is-over' : ''}`}
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files[0]); }}
        >
          <p><strong>Drop an image here</strong></p>
          <p className="fine">JPG, PNG or WebP, up to 12 MB</p>
          <button className="btn" onClick={() => inputRef.current.click()}>Choose image</button>
          <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" hidden
                 onChange={(e) => pick(e.target.files[0])} />
        </div>
      )}

      {file && !result && (
        <div className="stage">
          <div className="preview"><img src={preview} alt="Selected upload" /></div>
          <div className="row">
            <button className="btn" onClick={process} disabled={busy || outOfCredits}>
              {busy ? 'Removing background…' : 'Remove background'}
            </button>
            <button className="btn btn-ghost" onClick={reset} disabled={busy}>Choose another</button>
          </div>
          {outOfCredits && <p className="error">You have no credits left. <Link to="/pricing">Get more credits</Link></p>}
        </div>
      )}

      {result && (
        <div className="stage">
          <CompareSlider before={fileUrl(result.originalUrl)} after={fileUrl(result.resultUrl)} bg={bg} />
          <div className="swatches" role="radiogroup" aria-label="Background">
            {SWATCHES.map((s) => (
              <button
                key={s.label}
                role="radio" aria-checked={bg === s.value}
                className={`swatch ${bg === s.value ? 'on' : ''}`}
                data-checker={s.value === null}
                style={s.value ? { background: s.value } : undefined}
                onClick={() => setBg(s.value)}
                title={s.label} aria-label={s.label}
              />
            ))}
            <label className="swatch custom" title="Custom color">
              <input type="color" value={bg || '#ffffff'} onChange={(e) => setBg(e.target.value)} aria-label="Custom color" />
            </label>
          </div>
          <div className="row">
            <button className="btn" onClick={download}>Download PNG</button>
            <button className="btn btn-ghost" onClick={reset}>Process another image</button>
          </div>
        </div>
      )}

      {error && <p className="error" role="alert">{error}</p>}
    </section>
  );
}
