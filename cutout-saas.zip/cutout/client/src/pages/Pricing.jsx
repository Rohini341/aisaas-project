import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { errorMessage } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Pricing() {
  const { user, patchUser } = useAuth();
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState('');

  useEffect(() => { api.get('/api/billing/plans').then((r) => setPlans(r.data.plans)); }, []);

  async function buy(plan) {
    if (!user) return navigate('/register');
    setBusy(plan.id);
    setMsg('');
    try {
      const { data } = await api.post('/api/billing/purchase', { plan: plan.id });
      patchUser(data);
      setMsg(`Added ${plan.credits} credits. You now have ${data.credits}.`);
    } catch (e) { setMsg(errorMessage(e)); }
    finally { setBusy(''); }
  }

  return (
    <section className="pricing">
      <h1>Pay for the images you process</h1>
      <p className="lede">One credit removes one background. Credits never expire.</p>
      <div className="plans">
        {plans.map((p) => (
          <article key={p.id} className={`plan ${p.id === 'pro' ? 'plan-hot' : ''}`}>
            <h2>{p.name}</h2>
            <p className="price">{p.price === 0 ? 'Free' : `$${p.price}`}</p>
            <p><strong>{p.credits} credits</strong></p>
            <p className="fine">{p.blurb}</p>
            {p.price === 0
              ? <button className="btn btn-ghost" onClick={() => navigate(user ? '/app' : '/register')}>
                  {user ? 'Open the editor' : 'Start free'}
                </button>
              : <button className="btn" disabled={busy === p.id} onClick={() => buy(p)}>
                  {busy === p.id ? 'Adding…' : `Get ${p.credits} credits`}
                </button>}
          </article>
        ))}
      </div>
      {msg && <p className="notice" role="status">{msg}</p>}
      <p className="fine">Demo checkout: credits are added instantly without payment. Connect Stripe before going live (see README).</p>
    </section>
  );
}
