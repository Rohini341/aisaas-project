import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errorMessage, fileUrl } from '../api.js';

export default function History() {
  const [images, setImages] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/api/images')
      .then((r) => setImages(r.data.images))
      .catch((e) => setError(errorMessage(e)));
  }, []);

  async function remove(id) {
    if (!window.confirm('Delete this image permanently?')) return;
    try {
      await api.delete(`/api/images/${id}`);
      setImages((list) => list.filter((i) => i._id !== id));
    } catch (e) { setError(errorMessage(e)); }
  }

  return (
    <section className="history">
      <h1>My images</h1>
      {error && <p className="error">{error}</p>}
      {images && images.length === 0 && (
        <p className="center-note">Nothing here yet. <Link to="/app">Remove your first background</Link></p>
      )}
      <div className="grid">
        {(images || []).map((img) => (
          <figure key={img._id} className="tile">
            <div className="tile-img" data-checker="true">
              <img src={fileUrl(img.resultUrl)} alt={`Cutout of ${img.originalName}`} loading="lazy" />
            </div>
            <figcaption>
              <span title={img.originalName}>{img.originalName}</span>
              <span className="row">
                <a href={fileUrl(img.resultUrl)} download className="link-btn">Download</a>
                <button className="link-btn danger" onClick={() => remove(img._id)}>Delete</button>
              </span>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}
