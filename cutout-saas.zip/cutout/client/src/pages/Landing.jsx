import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

function Cutout() {
  // A potted plant outlined with "marching ants", the selection outline every editor draws
  const shape = (
    <>
      <path d="M70 250 L82 316 Q84 326 94 326 L146 326 Q156 326 158 316 L170 250 Z" />
      <path d="M120 250 C118 200 112 160 70 120 C100 112 128 130 138 170 C142 120 156 80 196 56 C196 110 170 150 150 200 C176 170 206 170 222 176 C200 214 160 214 128 252 Z" />
    </>
  );
  return (
    <svg viewBox="0 0 280 360" className="hero-art" role="img" aria-label="A potted plant selected with a dashed outline">
      <g className="plant-fill">{shape}</g>
      <g className="ants">{shape}</g>
    </svg>
  );
}

export default function Landing() {
  const { user } = useAuth();
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <h1>Photos in. Backgrounds out.</h1>
          <p className="lede">
            Upload a product shot, portrait or logo and get a clean transparent PNG in a few
            seconds. Drag a slider to check the edges, pick a new background, and download.
          </p>
          <div className="row">
            <Link to={user ? '/app' : '/register'} className="btn">
              {user ? 'Open the editor' : 'Remove your first background'}
            </Link>
            <Link to="/pricing" className="btn btn-ghost">See pricing</Link>
          </div>
          <p className="fine">5 free credits on sign-up. No card needed.</p>
        </div>
        <div className="hero-stage" data-checker="true">
          <Cutout />
        </div>
      </section>

      <section className="uses">
        <div>
          <h3>Store listings</h3>
          <p>White or transparent backgrounds that meet marketplace image rules.</p>
        </div>
        <div>
          <h3>Profile photos</h3>
          <p>Swap a messy room for a solid color before you hit upload.</p>
        </div>
        <div>
          <h3>Design assets</h3>
          <p>Get PNGs with clean edges you can drop straight into Figma or Canva.</p>
        </div>
      </section>
    </>
  );
}
