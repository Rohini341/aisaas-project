import mongoose from 'mongoose';

const imageSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    originalName: String,
    originalUrl: { type: String, required: true },
    resultUrl: { type: String, required: true },
    sizeBytes: Number,
  },
  { timestamps: true }
);

export default mongoose.model('Image', imageSchema);
