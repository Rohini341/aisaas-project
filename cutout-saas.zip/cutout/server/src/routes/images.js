import { Router } from 'express';
import multer from 'multer';
import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { protect } from '../middleware/auth.js';
import User from '../models/User.js';
import Image from '../models/Image.js';
import { removeBackground } from '../services/removeBg.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const UPLOAD_DIR = path.join(__dirname, '..', '..', 'uploads');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 12 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)) return cb(null, true);
    const e = new Error('Only JPG, PNG or WebP images are supported.');
    e.status = 400;
    cb(e);
  },
});

const router = Router();
router.use(protect);

router.post('/remove', upload.single('image'), async (req, res, next) => {
  let charged = false;
  try {
    if (!req.file) return res.status(400).json({ message: 'Choose an image to upload.' });

    // Atomically take 1 credit (prevents going below zero on parallel requests)
    const user = await User.findOneAndUpdate(
      { _id: req.user._id, credits: { $gt: 0 } },
      { $inc: { credits: -1 } },
      { new: true }
    );
    if (!user)
      return res.status(402).json({ message: 'You are out of credits. Get more on the pricing page.' });
    charged = true;

    const { buffer, ext } = await removeBackground(req.file.buffer, req.file.mimetype, req.file.originalname);

    const dir = path.join(UPLOAD_DIR, String(user._id));
    await fs.mkdir(dir, { recursive: true });
    const id = crypto.randomBytes(12).toString('hex');
    const sub = req.file.mimetype.split('/')[1];
    const origExt = sub === 'jpeg' ? 'jpg' : sub;
    const origName = `${id}-original.${origExt}`;
    const resName = `${id}-cutout.${ext}`;
    await fs.writeFile(path.join(dir, origName), req.file.buffer);
    await fs.writeFile(path.join(dir, resName), buffer);

    const image = await Image.create({
      user: user._id,
      originalName: req.file.originalname,
      originalUrl: `/uploads/${user._id}/${origName}`,
      resultUrl: `/uploads/${user._id}/${resName}`,
      sizeBytes: req.file.size,
    });

    res.status(201).json({ image, credits: user.credits });
  } catch (err) {
    if (charged) await User.updateOne({ _id: req.user._id }, { $inc: { credits: 1 } }); // refund
    next(err);
  }
});

router.get('/', async (req, res, next) => {
  try {
    const images = await Image.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(100);
    res.json({ images });
  } catch (err) { next(err); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const image = await Image.findOne({ _id: req.params.id, user: req.user._id });
    if (!image) return res.status(404).json({ message: 'Image not found.' });
    for (const url of [image.originalUrl, image.resultUrl]) {
      await fs.rm(path.join(UPLOAD_DIR, url.replace('/uploads/', '')), { force: true });
    }
    await image.deleteOne();
    res.json({ ok: true });
  } catch (err) { next(err); }
});

export default router;
