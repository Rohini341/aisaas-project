import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import User from '../models/User.js';

const router = Router();

export const PLANS = [
  { id: 'free',    name: 'Free',    price: 0,  credits: 5,   blurb: 'Try it on a few photos.' },
  { id: 'starter', name: 'Starter', price: 9,  credits: 50,  blurb: 'For a small shop or side project.' },
  { id: 'pro',     name: 'Pro',     price: 29, credits: 250, blurb: 'For catalogs and weekly uploads.' },
];

router.get('/plans', (req, res) => res.json({ plans: PLANS }));

/**
 * DEMO checkout: instantly adds credits.
 * Replace with Stripe Checkout + a webhook (checkout.session.completed) that does the same $inc.
 */
router.post('/purchase', protect, async (req, res, next) => {
  try {
    const plan = PLANS.find((p) => p.id === req.body.plan && p.price > 0);
    if (!plan) return res.status(400).json({ message: 'Choose a paid plan.' });

    const user = await User.findByIdAndUpdate(
      req.user._id,
      { $inc: { credits: plan.credits }, plan: plan.id },
      { new: true }
    );
    res.json({ credits: user.credits, plan: user.plan });
  } catch (err) { next(err); }
});

export default router;
