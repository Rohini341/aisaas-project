/**
 * Background removal provider.
 *  - removebg : calls the remove.bg AI API (set REMOVE_BG_API_KEY)
 *  - mock     : returns the original image so you can test the full flow for free
 *
 * To plug in another model (Photoroom, Clipdrop, a self-hosted rembg server...)
 * add a new function below and register it in `providers`.
 */
async function removeBgApi(buffer, mimetype, filename) {
  const key = process.env.REMOVE_BG_API_KEY;
  if (!key) {
    const e = new Error('REMOVE_BG_API_KEY is not set on the server.');
    e.status = 500;
    throw e;
  }

  const form = new FormData();
  form.append('image_file', new Blob([buffer], { type: mimetype }), filename || 'image');
  form.append('size', 'auto');
  form.append('format', 'png');

  const res = await fetch('https://api.remove.bg/v1.0/removebg', {
    method: 'POST',
    headers: { 'X-Api-Key': key },
    body: form,
  });

  if (!res.ok) {
    let detail = '';
    try {
      const body = await res.json();
      detail = body?.errors?.[0]?.title || '';
    } catch { /* ignore */ }
    const e = new Error(`Background removal failed${detail ? `: ${detail}` : '.'}`);
    e.status = 502;
    throw e;
  }
  return { buffer: Buffer.from(await res.arrayBuffer()), ext: 'png' };
}

async function mock(buffer, mimetype) {
  const sub = mimetype.split('/')[1];
  return { buffer, ext: sub === 'jpeg' ? 'jpg' : sub };
}

const providers = { removebg: removeBgApi, mock };

export async function removeBackground(buffer, mimetype, filename) {
  const name = process.env.BG_PROVIDER || 'mock';
  const fn = providers[name];
  if (!fn) throw new Error(`Unknown BG_PROVIDER "${name}"`);
  return fn(buffer, mimetype, filename);
}
